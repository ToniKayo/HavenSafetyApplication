package com.example.havenwomansafetyapp;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class EmergencyContacts extends AppCompatActivity {

    private static final String CONTACTS_PREFS = "ContactsPrefs";
    private static final String CONTACTS_KEY = "ContactsKey";

    private EditText contactNameEditText;
    private EditText contactNumberEditText;
    private ListView contactListView;
    private ArrayList<String> contactList;
    private ArrayAdapter<String> adapter;

    private SharedPreferences contactsPrefs;
    private SharedPreferences.Editor contactsEditor;

    private LocationManager locationManager;
    private LocationListener locationListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_contacts);

        contactNameEditText = findViewById(R.id.contact_name_edit_text);
        contactNumberEditText = findViewById(R.id.contact_number_edit_text);
        contactListView = findViewById(R.id.contact_list_view);
        Button addContactButton = findViewById(R.id.add_contact_button);
        Button sendLocationButton = findViewById(R.id.send_location_button);

        // Initialize contact list and adapter
        contactList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, contactList);
        contactListView.setAdapter(adapter);

        // Initialize SharedPreferences for saving contacts
        contactsPrefs = getSharedPreferences(CONTACTS_PREFS, Context.MODE_PRIVATE);
        contactsEditor = contactsPrefs.edit();

        // Load saved contacts
        loadContacts();

        // Add contact button click listener
        addContactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = contactNameEditText.getText().toString();
                String number = contactNumberEditText.getText().toString();
                String contact = name + ": " + number;
                contactList.add(contact);
                adapter.notifyDataSetChanged();

                // Save contact to SharedPreferences
                saveContacts();

                // Add contact to phone's contacts
                addContactToPhone(name, number);
            }
        });

        // Send location button click listener
        sendLocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!contactList.isEmpty()) {
                    // Prompt user to select a contact from the list
                    showContactSelectionDialog();
                } else {
                    Toast.makeText(EmergencyContacts.this, "No emergency contacts available", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    // Method to load saved contacts from SharedPreferences
    private void loadContacts() {
        String savedContacts = contactsPrefs.getString(CONTACTS_KEY, "");
        if (!savedContacts.isEmpty()) {
            String[] contactsArray = savedContacts.split(",");
            for (String contact : contactsArray) {
                contactList.add(contact);
            }
            adapter.notifyDataSetChanged();
        }
    }

    // Method to save contacts to SharedPreferences
    private void saveContacts() {
        StringBuilder stringBuilder = new StringBuilder();
        for (String contact : contactList) {
            stringBuilder.append(contact).append(",");
        }
        String contactsString = stringBuilder.toString();
        contactsEditor.putString(CONTACTS_KEY, contactsString);
        contactsEditor.apply();
    }

    // Method to add contact to phone's contacts
    private void addContactToPhone(String name, String number) {
        // Implementation to add contact to phone's contacts
    }

    // Method to send SMS with live location
    private void sendLocationSms(String contact) {
        // Implementation to send SMS with live location
    }

    // Method to show dialog for selecting a contact
    private void showContactSelectionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select a contact");

        // Convert ArrayList to array for dialog options
        final CharSequence[] contactOptions = contactList.toArray(new CharSequence[contactList.size()]);

        builder.setItems(contactOptions, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedContact = contactList.get(which);
                sendLocationSms(selectedContact);
            }
        });

        builder.show();
    }

    // Method to initiate phone call
    private void initiatePhoneCall(String phoneNumber) {
        Intent dialIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phoneNumber));
        startActivity(dialIntent);
    }

    // Method to send SMS message
    private void sendSmsMessage(String phoneNumber) {
        String message = "Here is my current location";
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phoneNumber));
        smsIntent.putExtra("sms_body", message);
        startActivity(smsIntent);
    }
}
