package com.example.havenwomansafetyapp;

public class Tip {
}
