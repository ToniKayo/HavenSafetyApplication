
package com.example.havenwomansafetyapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {

    CardView contactCard, locationCard, recCard, resCard, tipCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize CardViews for all buttons
        contactCard = findViewById(R.id.contactCard);
        locationCard = findViewById(R.id.locationCard);
        recCard = findViewById(R.id.recCard);
        resCard = findViewById(R.id.resCard);
        tipCard = findViewById(R.id.tipCard);

        // Set OnClickListener for the contact card
        contactCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the EmergencyContacts activity when contact card is pressed
                Intent intent = new Intent(MainActivity.this, EmergencyContacts.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for the location card
        locationCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the Location activity when location card is pressed
                Intent intent = new Intent(MainActivity.this, location.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for the record card
        recCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the Record activity when record card is pressed
                Intent intent = new Intent(MainActivity.this, Record.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for the resources card
        resCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the Resources activity when resources card is pressed
                Intent intent = new Intent(MainActivity.this, Resources.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for the tip card
        tipCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the Tip activity when tip card is pressed
                Intent intent = new Intent(MainActivity.this, Tip.class);
                startActivity(intent);
            }
        });
    }
}
